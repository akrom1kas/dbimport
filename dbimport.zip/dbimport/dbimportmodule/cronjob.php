<?php

require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');
//include_once(dirname(__FILE__).'dbimportmodule.php');

function cronjob(): void
{

	$server = Tools::getValue('DBIMPORTMODULE_SERVER', Configuration::get('DBIMPORTMODULE_SERVER'));
	$username = Tools::getValue('DBIMPORTMODULE_USERNAME', Configuration::get('DBIMPORTMODULE_USERNAME'));
	$password = Tools::getValue('DBIMPORTMODULE_PASSWORD', Configuration::get('DBIMPORTMODULE_PASSWORD'));
	$database = Tools::getValue('DBIMPORTMODULE_DATABASE', Configuration::get('DBIMPORTMODULE_DATABASE'));

	$conn = new mysqli($server, $username, $password, $database);
	$conn->set_charset("utf8");
	if ($conn->connect_error) {
		die('Connection failed: ' . $conn->connect_error());
	}

	$result = mysqli_query($conn, "SELECT katalogas.KatalogasID as product,
    leidimas.NomNr  as reference,
    leidimas.Svoris  as weight,
    leidykla.Pavadinimas as manufacturer,
    (SELECT struktura.Pavadinimas FROM Lala.struktura WHERE struktura.StrukturaID = busena.StrukturaId) as product_category,
    katalogas.Pavadinimas as name,
    leidimas.Anotacija as description,
    katalogas.Autorius as author,
    leidimas.ISBN as isbn,
    CONCAT_WS('<br>',CONCAT('http://localhost:8010/action.php?file=bW9kdWxpc3dlYi9pbWFnZS5waHA=&img=', TO_BASE64(CONCAT('/storage/lala/virselis/virselis', leidimas_img.LeidimasID, '_original.jpg')))) as product_image,

    0 as quantity,
    0.0 as price,
    0.00 as cost,
    CONCAT_WS(
      '<br>',
      'Autorius',
      'Tipas 1',
      'Tipas 2',
      'Metai',
      'Leidimo nr.',
      'Puslapių sk.',
      'ISBN',
      'eMetai',
      'eISBN',
      'eISSN',
      'DOI',
      'Būsena',
      'Formatas',
      'Viršelio tipas'
    ) as attributes,
    CONCAT_WS(
      '<br>',
      katalogas.Autorius,
      leidimas.TipasTxt,
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.tipas WHERE tipas.TipasID = leidimas.TipasID), ' '),
      leidimas.Metai,
      leidimas.LeidimoNr,
      leidimas.PslSk,
      leidimas.ISBN,
      leidimas.eMetai,
      leidimas.eISBN,
      leidimas.eISSN,
      leidimas.DOI,
      busena.busena,
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.formatas WHERE formatas.FormatasID = leidimas.FormatasID), ' '),
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.virselistipas WHERE virselistipas.VirselisTipasID = leidimas.VirselisTipasID), ' ')
    ) as product_attribute


	 FROM
        Lala.katalogas,
        Lala.leidimas,
        Lala.leidykla,
        Lala.busena
      INNER JOIN
        Lala.leidimas as leidimas_img
      WHERE
        katalogas.KatalogasID = leidimas.KatalogasID AND
        katalogas.LeidyklaID = leidykla.LeidyklaID AND
        katalogas.KatalogasID = busena.KatalogasID AND
        katalogas.KatalogasID = leidimas_img.KatalogasID AND
        leidimas.NomNr != '' AND
        (leidimas.NomNr LIKE CONCAT(SUBSTRING(YEAR(NOW()) - 1, 3, 2),'-', '%') or leidimas.NomNr LIKE CONCAT(SUBSTRING(YEAR(NOW()), 3, 2),'-', '%'))
      GROUP BY
        leidimas.LeidimasID
      ORDER BY
        leidimas.LeidimasID ASC");
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$reference_number = $row['reference'];
			$product_exists = Db::getInstance()->getValue("SELECT COUNT(*) FROM " . _DB_PREFIX_ . "product WHERE reference = '" . pSQL($reference_number) . "'");

			if ($product_exists == 0) {
				// Product doesn't exist, create it
				$new_product = new Product();
				$new_product->name = array(1 => $row['name']);
				$new_product->description = array(1 => $row['description']);
				$new_product->reference = $row['reference'];
				$new_product->weight = $row['weight'];
//				$new_product->id_manufacturer = $id_manufacturer;
//				$new_product->id_supplier = $supplier['id_supplier'];
				$category_id = 2;
//				$new_product->id_category_default = $category_id;
				$new_product->link_rewrite = array(1 => Tools::link_rewrite($row['name']));
				$new_product->quantity = 0;
				$new_product->minimal_quantity = 1;
				$new_product->price = $row['price'];
				$new_product->add();

				// Gauname naujo produkto ID
//				$product_id = $new_product->id;
//				// Priskiriame tiekėją naujai sukurtam produktui
//				$new_product->addSupplierReference($supplier['id_supplier'], $product_id);
				// Gauname visų produktų nuotraukų URL adresus
				$image_urls = $row['product_image'];
				if (!is_array($image_urls)) {
					$image_urls = array($image_urls);
				}
				$product_id = $new_product->id;
				$product = new Product($product_id);
				foreach ($image_urls as $image_url) {
					$image_content = file_get_contents($image_url);
					if (!$image_content) {
						continue; // Skip to the next image URL
					}
					$product_imageTest = new Image();
					$product_imageTest->id_product = $product->id;
					$product_imageTest->position = Image::getHighestPosition($product->id) + 1;
					$product_imageTest->cover = true;
					$product_imageTest->image_format = 'jpg';
					$product_imageTest->file_name = 'temp.jpg';
					$product_imageTest->add();
					$product_image = new Image($product_imageTest->id);
					$product_image->file_name = $product_imageTest->id . '.jpg';
					$directory = _PS_PROD_IMG_DIR_ . implode('/', str_split($product_image->id)) . '/';
					if (!file_exists($directory)) {
						mkdir($directory, 0777, true);
					}
					$image_path = $directory . $product_image->file_name;
					file_put_contents($image_path, $image_content);
					$product_image->update();
				}

//				$category_stringas = $row['product_category'];
//				$cat = explode('<br>', $category_stringas);
//				$categoryMap = getImportCategoryList();
//				print_r($categoryMap);



				$manufact_stringas = $row['manufacturer'];
				$manufact = explode('<br>', $manufact_stringas);
				$manufacturerMap = getImportManufacturerList();
				//print_r($manufacturerMap);
				foreach ($manufact as $manu) {
					if (!empty($manu)) {
						$limited_string = substr($manu, 0, 255);
						$manufacturerId = getManufacturerId($limited_string);

						if (empty($manufacturerId)) {
							Manufacturer::addManufacturerImport($limited_string);
							$manufacturerId = getManufacturerId($limited_string);
						}
						if (isset($product->id)) {
							$productId = $product->id;
							if (empty(getFeature($manufacturerMap, $productId, $manufacturerId))) {
								something($manufacturerMap, $productId, $manufacturerId);
							}
						}
					}
				}
				$rakto_stringas = $row['attributes'];
				$reiksmes_stringas = $row['product_attribute'];
				$raktai = explode('<br>', $rakto_stringas);
				$reiksmes = explode('<br>', $reiksmes_stringas);
				$featureMap = getImportFeatureList();
				//print_r($featureMap);
				for ($i = 0; $i < count($raktai); $i++) {
					$name = $raktai[$i];
					if (isset($featureMap[$name])) {
						$value = $reiksmes[$i];
						$limited_string = substr($value, 0, 255);
						$featureValue = getFeatureValueId($limited_string);

						if (!empty($value) && empty($featureValue)) {
							FeatureValue::addFeatureValueImport($featureMap[$name], $limited_string, null, null, true);
							$featureValue = getFeatureValueId($limited_string);
						}
						if (isset($product->id)) {
							$productId = $product->id;
							if (empty(getFeature($featureMap[$name], $productId, $featureValue))) {
								something($featureMap[$name], $productId, $featureValue);
							}
						}
					}
				}
			}
		}
	}
	echo "Hello";
}

function getImportFeatureList()
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('*');
	$query->from('import_feature');
	$result = $Db->executeS($query);

	$return = [];

	foreach ($result as $res) {
		$return[$res['title']] = $res['feature_id'];
	}

	return $return;
}

function something($featureId, $productId, $featureValue)
{
	$db = Db::getInstance();
	$table_name = 'feature_product';
	$data = array(
		'id_feature' => (int)$featureId,
		'id_product' => (int)$productId,
		'id_feature_value' => (int)$featureValue,
	);
	$db->insert($table_name, $data);
}

function getFeature($featureId, $productId, $featureValue, $manufacturerId = null)
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('id_feature');
	$query->from('feature_product');
	$query->where('id_feature = \'' . (int)$featureId . '\'');
	$query->where('id_product = \'' . (int)$productId . '\'');
	$query->where('id_feature_value = \'' . pSQL($featureValue) . '\'');

	if ($manufacturerId !== null) {
		$query->where('id_manufacturer = \'' . (int)$manufacturerId . '\'');
	}

	$result = $Db->getValue($query);
	return $result;
}

function getFeatureId($name)
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('id_feature');
	$query->from('feature_lang');
	$query->where('name = \'' . $name . '\'');
	$query->where('id_lang = 1');
	$result = $Db->getValue($query);
	return $result;
}

function getFeatureValueId($value)
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('id_feature_value');
	$query->from('feature_value_lang');
	$query->where('value = \'' . $value . '\'');
	$query->where('id_lang = 1');
	$result = $Db->getValue($query);
	return $result;
}

function getManufacturerId($manufacturerName)
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('id_manufacturer');
	$query->from('manufacturer');
	$query->where('name = \'' . $manufacturerName . '\'');
	$result = $Db->getValue($query);
	return $result;
}

function getImportManufacturerList()
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('*');
	$query->from('import_manufacturer');
	$result = $Db->executeS($query);

	$return = [];

	foreach ($result as $res) {
		$return[$res['title']] = $res['manufacturer_id'];
	}

	return $return;
}

function getImportCategoryList()
{
	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('*');
	$query->from('import_category');
	$result = $Db->executeS($query);

	$return = [];

	foreach ($result as $res) {
		$return[$res['title']] = $res['manufacturer_id'];
	}

	return $return;
}

cronjob();